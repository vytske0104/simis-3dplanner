var SAPBroadphase = require(__dirname + '/../../src/collision/SAPBroadphase');

exports.construct = function(test){
    var broadphase = new SAPBroadphase();
    test.done();
};

exports.checkBounds = function(test){
    // STUB
    test.done();
};

exports.getCollisionPairs = function(test){
    // STUB
    test.done();
};

exports.setWorld = function(test){
    // STUB
    test.done();
};

exports.sortAxisListX = function(test){
    // STUB
    test.done();
};

exports.sortAxisListY = function(test){
    // STUB
    test.done();
};

