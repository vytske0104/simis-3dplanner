var DistanceConstraint = require(__dirname + '/../../src/constraints/DistanceConstraint');

exports.construct = function(test){
    // STUB
    test.done();
};

exports.getMaxForce = function(test){
    // STUB
    test.done();
};

exports.setMaxForce = function(test){
    // STUB
    test.done();
};

exports.update = function(test){
    // STUB
    test.done();
};

