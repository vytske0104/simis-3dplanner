var AngleLockEquation = require(__dirname + '/../../src/equations/AngleLockEquation');

exports.construct = function(test){
    // STUB
    test.done();
};

